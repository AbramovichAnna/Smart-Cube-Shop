import { useState, useEffect } from "react";

export const useApi = (apiFunc) => {
    const [data, setData] = useState([]);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        setLoading(true);
        apiFunc()
            .then(response => {
                setData(response.data);
                setError(null);
            })
            .catch(error => {
                setError(error);
                setData([]);
            })
            .finally(() => setLoading(false));
    }, [apiFunc]);

    return { data, error, loading };
};
