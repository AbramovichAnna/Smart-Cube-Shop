import React from 'react';
import axios from 'axios';
import { HOST_URL } from '../../common/constants';

function AddToCartButton({ productId }) {
    const addToCart = () => {
        axios.post(`${HOST_URL}/cart_items/`, { product: productId, quantity: 1 })
            .then(response => {
                console.log(response.data);
            })
            .catch(error => console.error('Error adding to cart', error));
    };

    return <button className="btn products_btn " onClick={addToCart}>Add to Cart</button>;
}

export default AddToCartButton;
