

// DJANGO_BACKEND_API_URL
export const HOST_URL = "https://shop-api-763v.onrender.com";
// export const HOST_URL = "http://localhost:8000";